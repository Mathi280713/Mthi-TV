(() => {
  'use strict';
  const STORAGE = { channels: 'mthitv.channels.v1', favorites: 'mthitv.favorites.v1' };
  const starterChannels = [
    { id: 'mthi-music', name: 'MTHI Música', category: 'Música', description: 'Sesiones, descubrimientos musicales y contenido original autorizado.', initials: 'MUSIC', art: 'art-music', type: '', url: '', builtin: true },
    { id: 'mthi-play', name: 'MTHI Play', category: 'Entretenimiento', description: 'Cultura digital, entrevistas, ideas y entretenimiento para descubrir.', initials: 'PLAY', art: 'art-play', type: '', url: '', builtin: true },
    { id: 'mthi-explora', name: 'MTHI Explora', category: 'Ciencia y cultura', description: 'Historias del mundo, ciencia, naturaleza y conocimiento.', initials: 'EXPLORE', art: 'art-explore', type: '', url: '', builtin: true }
  ];
  const $ = s => document.querySelector(s);
  const grid = $('#channel-grid'), searchInput = $('#search-input'), dialog = $('#add-dialog'), form = $('#add-form');
  let activeView = 'home', activeCategory = 'Todos', editingId = null, toastTimer = null, currentPlayerUrl = '';
  const safeRead = (key, fallback) => { try { const value = JSON.parse(localStorage.getItem(key)); return value ?? fallback; } catch { return fallback; } };
  let customChannels = safeRead(STORAGE.channels, []);
  let favorites = safeRead(STORAGE.favorites, []);
  if (!Array.isArray(customChannels)) customChannels = [];
  if (!Array.isArray(favorites)) favorites = [];
  const channels = () => [...starterChannels.map(c => ({ ...c, ...(customChannels.find(x => x.id === c.id) || {}) })), ...customChannels.filter(c => !starterChannels.some(s => s.id === c.id))];
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const save = () => { try { localStorage.setItem(STORAGE.channels, JSON.stringify(customChannels)); localStorage.setItem(STORAGE.favorites, JSON.stringify(favorites)); } catch { showToast('El navegador no permitió guardar los cambios.'); } };
  function showToast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2600); }
  function artClass(channel) { return channel.art || 'art-custom'; }
  function render() {
    const all = channels();
    const query = searchInput.value.trim().toLocaleLowerCase('es');
    const visible = all.filter(c => (activeView !== 'favorites' || favorites.includes(c.id)) && (activeCategory === 'Todos' || c.category === activeCategory) && (!query || `${c.name} ${c.category} ${c.description}`.toLocaleLowerCase('es').includes(query)));
    $('#catalog-title').textContent = activeView === 'favorites' ? 'Tu lista' : activeView === 'channels' ? 'Todos los canales' : 'Explorá los canales';
    $('#catalog-sub').textContent = activeView === 'favorites' ? 'Tus canales guardados en este navegador.' : 'Canales originales y señales autorizadas, en un solo lugar.';
    $('#fav-count').textContent = favorites.length;
    $('#hero').hidden = activeView !== 'home';
    $('#filter-row').hidden = activeView === 'favorites';
    grid.innerHTML = visible.map(c => {
      const isFav = favorites.includes(c.id), ready = Boolean(c.url && c.type);
      const initials = c.initials || c.name.split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
      return `<article class="channel-card"><div class="channel-art ${artClass(c)}"><span class="art-corner">${ready ? 'SEÑAL DISPONIBLE' : 'MTHI TV'}</span><span class="art-code">${escapeHtml(initials)}${c.builtin ? '' : '<small>CANAL</small>'}</span><button class="fav-button ${isFav ? 'is-fav' : ''}" data-fav="${escapeHtml(c.id)}" aria-label="${isFav ? 'Quitar de mi lista' : 'Añadir a mi lista'}" title="${isFav ? 'Quitar de mi lista' : 'Añadir a mi lista'}">${isFav ? '★' : '☆'}</button></div><div class="channel-meta"><div class="channel-title-row"><h3 class="channel-title">${escapeHtml(c.name)}</h3><span class="status ${ready ? 'ready' : ''}">${ready ? 'CONFIGURADO' : 'EN PREPARACIÓN'}</span></div><p class="channel-desc">${escapeHtml(c.description || (ready ? 'Señal guardada en este navegador.' : 'Este canal todavía no tiene una fuente configurada.'))}</p><div class="channel-bottom"><span class="channel-category">${escapeHtml(c.category)}</span><button class="channel-action" data-play="${escapeHtml(c.id)}">${ready ? '▶ Ver canal' : '＋ Configurar'}</button></div></div></article>`;
    }).join('');
    $('#empty-state').hidden = visible.length !== 0;
    $('#channel-count');
  }
  function setView(view) {
    activeView = view;
    document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    if (view === 'home') { activeCategory = 'Todos'; setCategoryButtons(); }
    render();
    if (view !== 'home') $('#catalog').scrollIntoView({ behavior: 'smooth', block: 'start' }); else window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function setCategoryButtons() { document.querySelectorAll('[data-category]').forEach(b => b.classList.toggle('selected', b.dataset.category === activeCategory)); }
  function openAdd(channel = null) {
    editingId = channel?.id || null;
    $('#form-title').textContent = editingId ? `Configurar ${channel.name}` : 'Añadir un canal';
    $('#channel-name').value = channel?.name || '';
    $('#channel-category').value = channel?.category || 'Música';
    $('#channel-type').value = channel?.type || 'video';
    $('#channel-url').value = channel?.url || '';
    $('#form-error').hidden = true;
    dialog.showModal();
  }
  function validUrl(value) {
    try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol) ? u : null; } catch { return null; }
  }
  function saveChannel(event) {
    event.preventDefault();
    const name = $('#channel-name').value.trim(), category = $('#channel-category').value, type = $('#channel-type').value, url = $('#channel-url').value.trim();
    const parsed = validUrl(url);
    if (!name || !parsed) { $('#form-error').textContent = 'Escribí un nombre y una URL válida que comience con https:// o http://.'; $('#form-error').hidden = false; return; }
    if (parsed.protocol !== 'https:' && location.protocol === 'https:') { $('#form-error').textContent = 'En una web HTTPS, algunas fuentes HTTP se bloquean. Preferí una URL HTTPS.'; $('#form-error').hidden = false; return; }
    const old = channels().find(c => c.id === editingId);
    const channel = { id: editingId || `custom-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, name, category, type, url, description: old?.description || 'Señal agregada localmente. La compatibilidad depende de la fuente y el navegador.', initials: name.split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase(), art: old?.art || 'art-custom', builtin: Boolean(old?.builtin) };
    customChannels = customChannels.filter(c => c.id !== channel.id);
    customChannels.push(channel); save(); dialog.close(); activeView = 'channels'; document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === activeView)); render(); showToast('Canal guardado en este navegador.'); openPlayer(channel.id);
  }
  function openPlayer(id) {
    const channel = channels().find(c => c.id === id); if (!channel) return;
    $('#player-section').hidden = false; $('#player-title').textContent = channel.name;
    const wrap = $('#player-wrap'); wrap.innerHTML = '';
    if (!channel.url || !channel.type) {
      wrap.innerHTML = `<div class="player-placeholder"><div class="play-large">＋</div><h3>${escapeHtml(channel.name)} todavía no tiene señal</h3><p>Configurá una fuente propia o autorizada para poder reproducir este canal.</p><button class="btn-primary" id="player-configure">＋ Configurar señal</button></div>`;
      $('#player-configure').addEventListener('click', () => openAdd(channel));
      $('#player-disclaimer').textContent = 'No se ha agregado ninguna transmisión a este canal.';
    } else if (channel.type === 'embed') {
      const iframe = document.createElement('iframe'); iframe.src = channel.url; iframe.title = channel.name; iframe.allow = 'autoplay; fullscreen; picture-in-picture; encrypted-media'; iframe.allowFullscreen = true; iframe.referrerPolicy = 'strict-origin-when-cross-origin'; wrap.appendChild(iframe);
      $('#player-disclaimer').textContent = 'La reproducción depende de que el proveedor permita la inserción en otros sitios.';
    } else {
      const video = document.createElement('video'); video.controls = true; video.autoplay = false; video.playsInline = true; video.preload = 'metadata'; video.src = channel.url; video.setAttribute('aria-label', `Reproductor de ${channel.name}`); wrap.appendChild(video);
      $('#player-disclaimer').textContent = 'Si no reproduce, puede que el formato, CORS o el navegador de la TV no sea compatible con esta fuente.';
      video.addEventListener('error', () => showToast('No se pudo reproducir esta fuente. Revisá el enlace y la compatibilidad.'));
    }
    currentPlayerUrl = channel.url || ''; $('#player-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  document.querySelectorAll('.nav-link').forEach(b => b.addEventListener('click', () => setView(b.dataset.view)));
  document.querySelectorAll('[data-category]').forEach(b => b.addEventListener('click', () => { activeCategory = b.dataset.category; setCategoryButtons(); render(); }));
  searchInput.addEventListener('input', render);
  grid.addEventListener('click', event => {
    const fav = event.target.closest('[data-fav]'), play = event.target.closest('[data-play]');
    if (fav) { const id = fav.dataset.fav; favorites = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites, id]; save(); render(); showToast(favorites.includes(id) ? 'Añadido a Mi lista.' : 'Quitado de Mi lista.'); }
    if (play) { const channel = channels().find(c => c.id === play.dataset.play); if (channel && channel.url && channel.type) openPlayer(channel.id); else openAdd(channel); }
  });
  ['open-add-top', 'open-add-hero', 'open-add-bottom', 'empty-add', 'player-add'].forEach(id => $(`#${id}`).addEventListener('click', () => openAdd()));
  $('#explore-btn').addEventListener('click', () => { setView('channels'); });
  $('#close-add').addEventListener('click', () => dialog.close()); $('#cancel-add').addEventListener('click', () => dialog.close());
  $('#close-player').addEventListener('click', () => { $('#player-section').hidden = true; $('#player-wrap').innerHTML = ''; currentPlayerUrl = ''; });
  $('#channel-type').addEventListener('change', () => { $('#url-note').textContent = $('#channel-type').value === 'embed' ? 'Pegá la URL del reproductor insertable que el proveedor autoriza. Algunos sitios bloquean la carga en iframe.' : 'Usá un enlace directo a un video o a una transmisión HLS que tengas permiso de compartir. No todas las fuentes son compatibles con todos los navegadores.'; });
  form.addEventListener('submit', saveChannel);
  $('#year').textContent = new Date().getFullYear();
  render();
})();
