MTHI TV — PRIMERA VERSIÓN FUNCIONAL (1.0)
========================================

DISEÑO Y FUNCIONES
- Identidad oscura profesional con negro, azul eléctrico y acentos cian.
- Diseño adaptable a celular, computadora y Smart TV.
- Navegación Inicio / Canales / Mi lista.
- Búsqueda y filtros por categoría.
- Tres canales iniciales MTHI: Música, Play y Explora.
- Favoritos guardados en el almacenamiento local del navegador.
- Formulario para agregar y configurar canales con una URL autorizada.
- Reproductor HTML5 para video directo y algunas fuentes HLS, o iframe para reproductores que permiten inserción.
- No requiere cuentas, suscripciones, pagos, backend ni base de datos.

IMPORTANTE SOBRE LAS TRANSMISIONES
Esta versión funcional incluye el catálogo y el reproductor, pero NO incluye enlaces de transmisiones de terceros preinstalados. Los tres canales MTHI aparecen en preparación hasta que les agregués fuentes reales y autorizadas. No se muestran como EN VIVO si no hay señal configurada.

Los canales añadidos y favoritos se guardan solo en el navegador y dispositivo actual. No se sincronizan con otros dispositivos o visitantes. La compatibilidad depende de la fuente, permisos de inserción, HTTPS, CORS y el navegador (incluido BrowseHere en algunas TCL). No agregués señales que no tengas derecho a compartir.

PUBLICAR / ACTUALIZAR EN CLOUDFLARE PAGES DESDE EL REDMI
1. Descargá mthi-tv-v1.zip y descomprimilo con el administrador de archivos.
2. Entrá a https://dash.cloudflare.com/ e iniciá sesión en la cuenta que administra la web actual.
3. Abrí Workers & Pages y seleccioná el proyecto que publica MTHI TV.
4. Buscá la opción para crear un nuevo deployment/subir archivos estáticos (el texto exacto puede variar según el tipo de proyecto).
5. Subí los archivos index.html, styles.css y app.js desde la raíz del proyecto. README.txt es solo documentación.
6. Confirmá el despliegue y abrí la URL actual. Probá Inicio, búsqueda, filtros, favoritos y el formulario para agregar una fuente autorizada.

Si el proyecto actual es un Worker con código en vez de Pages/Direct Upload, no reemplaces el Worker con estos archivos sin comprobar el método de despliegue. Guardá una copia de la versión anterior antes de publicar.

PRUEBA RÁPIDA
- Abrí la web y confirmá que aparecen MTHI Música, MTHI Play y MTHI Explora.
- Guardá un canal con la estrella y entrá a Mi lista.
- Añadí una fuente de video propia/autorizada y probá Ver canal.
- Repetí en la TCL. Si una señal no funciona, probala primero en el Redmi: el reproductor del televisor puede admitir menos formatos.
